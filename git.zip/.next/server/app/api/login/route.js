var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/login/route.js")
R.c("server/chunks/[root-of-the-server]__195a41ae._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_login_route_actions_a124d239.js")
R.m(25586)
module.exports=R.m(25586).exports
