var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/register/route.js")
R.c("server/chunks/[root-of-the-server]__d527538e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_register_route_actions_688c24b5.js")
R.m(88655)
module.exports=R.m(88655).exports
