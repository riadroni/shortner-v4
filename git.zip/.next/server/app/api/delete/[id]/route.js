var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/delete/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__24c85dcf._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_delete_[id]_route_actions_c56e45fd.js")
R.m(60453)
module.exports=R.m(60453).exports
