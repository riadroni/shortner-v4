var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/logout/route.js")
R.c("server/chunks/[root-of-the-server]__37e7f485._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_logout_route_actions_3819575f.js")
R.m(55778)
module.exports=R.m(55778).exports
