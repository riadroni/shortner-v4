var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/create/route.js")
R.c("server/chunks/[root-of-the-server]__e310bbcf._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_create_route_actions_7866397b.js")
R.m(52027)
module.exports=R.m(52027).exports
