var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/links/route.js")
R.c("server/chunks/[root-of-the-server]__2180f37c._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_links_route_actions_c1fa4b40.js")
R.m(77690)
module.exports=R.m(77690).exports
