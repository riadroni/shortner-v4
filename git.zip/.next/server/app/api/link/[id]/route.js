var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/link/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__ab300ad2._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_link_[id]_route_actions_a8593f3a.js")
R.m(70101)
module.exports=R.m(70101).exports
