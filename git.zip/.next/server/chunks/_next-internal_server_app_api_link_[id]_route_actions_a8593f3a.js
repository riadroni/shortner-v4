module.exports=[35860,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_link_%5Bid%5D_route_actions_a8593f3a.js.map