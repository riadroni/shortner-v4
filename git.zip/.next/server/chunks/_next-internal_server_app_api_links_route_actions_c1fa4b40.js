module.exports=[13637,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_links_route_actions_c1fa4b40.js.map