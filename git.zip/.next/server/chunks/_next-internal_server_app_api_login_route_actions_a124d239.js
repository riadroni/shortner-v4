module.exports=[1287,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_login_route_actions_a124d239.js.map