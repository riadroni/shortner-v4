module.exports=[41101,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_register_route_actions_688c24b5.js.map