module.exports=[86210,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_create_route_actions_7866397b.js.map