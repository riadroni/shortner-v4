module.exports=[61661,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Bid%5D_page_actions_09930ec4.js.map