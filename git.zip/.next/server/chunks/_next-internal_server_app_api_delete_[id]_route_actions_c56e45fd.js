module.exports=[56774,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_delete_%5Bid%5D_route_actions_c56e45fd.js.map